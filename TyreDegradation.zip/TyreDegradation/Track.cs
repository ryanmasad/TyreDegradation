﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TyreDegradation
{
    public class Track
    {
        public string Name { get; set; }

        public string Location { get; set; }

        public int[] DegCoefficients { get; set; }

        public double Temperature { get; set; }

        public Track(string name, string location, int[] degCoefficients, double temperature)
        {
            Name = name;
            Location = location;
            DegCoefficients = degCoefficients;
            Temperature = temperature;

        }

    }
}
