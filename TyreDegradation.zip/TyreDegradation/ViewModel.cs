﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace TyreDegradation
{
    public class ViewModel
    {
        public Dictionary<string, Tyre> Tyres { set; get; }
        public Dictionary<string, Track> Tracks { set; get; }

        HttpClient client = new HttpClient();

        public Dictionary<string, Tyre> LoadTyreData(string path)

        {
            Dictionary<String, Tyre> TheseTyres = new Dictionary<String, Tyre>();
            XDocument tyreTypes = XDocument.Load(@path);

            foreach (XElement tyretype in tyreTypes.Elements("Tyres").Elements("Tyre"))
            {


                int degCo = 0;
                try
                {
                    degCo = Int32.Parse(tyretype.Element("DegradationCoefficient").Value);
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e.Message);
                }

                TheseTyres.Add(tyretype.Element("Name").Value, new Tyre(tyretype.Element("Name").Value,
                    tyretype.Element("Placement").Value,
                    tyretype.Element("Type").Value,
                    tyretype.Element("Family").Value,
                    degCo
                    ));

            }

            return TheseTyres;

        }

        public Dictionary<string, Track> LoadTrackData(string path)
        {
            string line;
            Dictionary<String, Track> theseTracks = new Dictionary<string, Track>();

            System.IO.StreamReader file = new System.IO.StreamReader(@path);

            while ((line = file.ReadLine()) != null)
            {
                String name = "";
                String location = "";
                String degCos = "";

                int[] degCoefficients = new int[0];
                double temperature = 0;

                String[] tokens = line.Split("|");
                if (tokens.Length != 3)
                {
                    continue;
                }
                else
                {
                    name = tokens[0];
                    location = tokens[1];
                    degCos = tokens[2];

                    String[] degCosArray = degCos.Split(",");
                    degCoefficients = Array.ConvertAll(degCosArray, int.Parse);
                    temperature = 10;
                }

                Track newTrack = new Track(name, location, degCoefficients, temperature);

                theseTracks.Add(name, newTrack);

            }
            return theseTracks;


        }

        public async Task<double> GetCurrentTempAsync(string location)
        {
            double temperature = 0;

            try
            {
                string requestURL = String.Format("https://api.openweathermap.org/data/2.5/weather?q={0}&appid=77e2991a0ab1fb9a2e9698513d743475&mode=xml", location);
                HttpResponseMessage response = await client.GetAsync(requestURL);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                XDocument weatherData = XDocument.Parse(responseBody);

                temperature = double.Parse(weatherData.Element("current").Element("temperature").Attribute("value").Value);
                temperature -= 273.15;
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }

            return await Task.FromResult(temperature);

        }

        public int[] CalculateDegradation(String track, String tyreType, int temperature)
        {
            Track currentTrack = Tracks[track];
            int[] degPoints = currentTrack.DegCoefficients;
    

            Tyre currentTyre = Tyres[tyreType];
            int tyreCoef = currentTyre.DegredationCoefficient;


            int[] pointDegs = new int[degPoints.Length];
            int index = 0;
            foreach (int degPointValue in degPoints)
            {
                double pointDeg = (degPointValue * temperature) / tyreCoef;
                pointDegs[index] = (int)Math.Round(pointDeg);
                index++;
            }

            //resultArray = {<average>,<mode>,<range>}
            int[] resultArray = new int[3];
            resultArray[0] = (int)Math.Round(pointDegs.Average());
            resultArray[1] = getMode(pointDegs);
            resultArray[2] = pointDegs.Max() - pointDegs.Min();

            return resultArray;

        }

        //adapted from https://www.geeksforgeeks.org/mode/
        public int getMode(int[] arr)
        {
            int max = arr.Max();

            int t = max + 1;
            int[] count = new int[t];
            for (int i = 0; i < t; i++)
                count[i] = 0;

            for (int i = 0; i < arr.Length; i++)
                count[arr[i]]++;

            // mode is the index with maximum count 
            int mode = 0;
            int k = count[0];
            for (int i = 1; i < t; i++)
            {
                if (count[i] > k)
                {
                    k = count[i];
                    mode = i;
                }
            }
            return mode;
        }

        public ViewModel()
        {
            Tyres = new Dictionary<string, Tyre>();
            Tracks = new Dictionary<string, Track>();
            Tyres = LoadTyreData(@"C:\Users\User\Documents\Renault Coding Challenge\TyreDegradation\TyreDegradation\TyresXML.xml");
            Tracks = LoadTrackData(@"C:\Users\User\Documents\Renault Coding Challenge\TyreDegradation\TyreDegradation\TrackDegradationCoefficients.txt");
        }
    }
}
